package com.cognizant.objectified.controller;
import org.apache.log4j.Logger;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.objectified.dao.CoursesDaoImpl;
//import com.cognizant.objectified.model.Courses;


@WebServlet("/AddCourses")
public class AddCourses extends HttpServlet {
	private static final long serialVersionUID = 1L;
    CoursesDaoImpl dao = new CoursesDaoImpl();   
    static Logger log = Logger.getLogger(AddCourses.class);
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		String name=request.getParameter("id1");
		String mode=request.getParameter("id2");
		String desc=request.getParameter("id3");
		//log.debug("message");
		//Courses course=new Courses(id, name, mode);
		String msg="";
		msg=dao.addCourses(name, mode, desc);
		pw.write(msg);
		//RequestDispatcher rd=request.getRequestDispatcher("admin.jsp");
		//rd.include(request, response);
		}
	}


